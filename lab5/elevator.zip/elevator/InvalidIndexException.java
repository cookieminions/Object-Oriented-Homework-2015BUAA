package elevator;

public class InvalidIndexException extends Exception {

}
