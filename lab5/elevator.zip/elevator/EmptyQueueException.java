package elevator;

public class EmptyQueueException extends Exception {

}
