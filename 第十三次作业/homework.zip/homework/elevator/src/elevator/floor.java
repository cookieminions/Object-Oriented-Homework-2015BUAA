package elevator;

public class floor {
	private int floor;
	floor(int num){
		floor = num;
	}
	public int get_floor(){
		return floor;
	}
}
