package elevator;

public interface abstract_elevator {
	public void set_floor(int f);
	public int get_floor();
	public String get_direction();
}
