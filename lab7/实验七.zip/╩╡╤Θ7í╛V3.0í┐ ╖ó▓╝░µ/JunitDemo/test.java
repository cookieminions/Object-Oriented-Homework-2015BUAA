



	public class test {

		/**
		 * @param args
		 * @throws Exception 
		 */
		public static void main(String[] args) throws Exception {
			// TODO Auto-generated method stub
	      PushBox pb=new PushBox();
	    
	      pb.readmap();
	      pb.bfs();
	      
		}
	}



