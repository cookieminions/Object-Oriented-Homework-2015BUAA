package IFTTT;

import java.util.Scanner;
import java.util.Vector;

public class Handle {
	private static Scanner s_in;
	private Vector<Task> task_list;
	
	Handle() {
		task_list = new Vector<Task>();
	}
	
	public void input_handle() {
		s_in = new Scanner(System.in);
		String line = "";
		while(!((line = s_in.nextLine()).equals("start"))){
			check_task(line);
			Task task = trans_task(line);
			if(task!=null){
				if(check(task))
					task_list.add(task);
			}
		}
	}
	
	public void check_task(String str){
		
		
		
		String[] list = str.split(" ");
		
		
		
		
		
		
		
	}
	
	public Task trans_task(String str){
		Task tmp_task = null;
		try{
			tmp_task = new Task(str);
		}
		catch (Exception e) {
			System.out.println("INVALID "+str);
			tmp_task = null;
		}
		return tmp_task;	
	}
	
	public boolean check(Task task){
		if(task.get_task().equals("recover")&&!(task.get_trigger().equals("renamed")||task.get_trigger().equals("path-changed"))){
			System.out.println("INVALID "+task.toString());
			return false;
		}
		for(int i=0;i<task_list.size();i++){
			Task tmp_task = task_list.get(i);
			if(tmp_task.equals(task))
				return false;
		}
		return true;
	}
	
	public Vector<Task> get_tasklist(){
		return task_list;
	}
	
}
