package IFTTT;

public class summary {
	private String[] trigger_type = {"renamed","Modified","path-changed","size-changed"};
	private int[] trigger_record = {0,0,0,0};
	summary() {
		
	}
	
	public synchronized void record(String trigger) {
		for(int i=0;i<4;i++){
			if(trigger.equals(trigger_type[i])){
				trigger_record[i]++;
				break;
			}
		}
	}
}
