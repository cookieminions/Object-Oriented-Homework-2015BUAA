package IFTTT;

import java.awt.event.MouseWheelEvent;
import java.util.Vector;

import javax.imageio.ImageTypeSpecifier;

public class Monitor extends Thread{
	private Task task;
	private String trigger;
	
	private FileList file_shell;
	private snapshot lastsnapshot;
	private snapshot currsnapshot;
	private file_target main_target;
	
	Monitor(String tmp_trigger,Task tmp_task,FileList filelist,file_target tmp_target){
		trigger = tmp_trigger;
		task = tmp_task;
		file_shell = filelist;
		main_target = tmp_target;
		lastsnapshot = new snapshot();
		currsnapshot = new snapshot();
	}
	
	public void run(){
		if(main_target.type.equals("File"))
			monitor(currsnapshot.root, main_target.parent_d);
		else
			monitor(currsnapshot.root, main_target.path);
		update();
		System.out.println(main_target.path);
		if(lastsnapshot.root!=null)
			System.out.println(lastsnapshot.root.target.path);
		main_target = lastsnapshot.search(lastsnapshot.root,main_target).target;
		
		while(true){
			if(main_target.type.equals("File"))
				monitor(currsnapshot.root, main_target.parent_d);
			else
				monitor(currsnapshot.root, main_target.path);
			check_trigger();
			update();
			file_shell.refresh();
			try {
				sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void monitor(file_node root,String path){
		safe_file file = file_shell.get_shell(path);
		
		String name_tmp = file.getName();String pd_tmp = file.getParent();String path_tmp = file.getPath();
		long mt_tmp = file.lastModified();long size_tmp = file.getlength();
		String type_tmp = file.isDirectory()?"Directory":"File";
		file_target target = new file_target(type_tmp, name_tmp, pd_tmp, path_tmp, size_tmp, mt_tmp);
		System.out.println(type_tmp+" "+name_tmp+" "+pd_tmp+" "+path_tmp+" "+size_tmp+" "+mt_tmp);
		
		String[] filelist = file.filelist();
		
		file_node target_node = new file_node(target);
		currsnapshot.add_node(root, target_node);
		
		if(filelist!=null){
			for(int i=0;i<filelist.length;i++){
				System.out.println(filelist[i]);
				monitor(target_node,filelist[i]);
			}
		}
	}
	
	public void check_trigger(){
		if(trigger.equals("renamed")){
			if(main_target.type.equals("File")){
				file_target last_target = lastsnapshot.search(lastsnapshot.root, main_target)!=null?lastsnapshot.search(lastsnapshot.root, main_target).target:null;
				file_target curr_target = currsnapshot.search(currsnapshot.root, main_target)!=null?currsnapshot.search(currsnapshot.root, main_target).target:null;
				if(last_target!=null&&curr_target==null){
					file_node renamed_node = currsnapshot.renamed_search(currsnapshot.root, main_target);
					if(renamed_node!=null){
						work();
						main_target = renamed_node.target;
					}
				}
				
			}else if(main_target.type.equals("Directory")){
				renamed_compare(main_target);
			}
		}
		else if(trigger.equals("Modified")){
			file_target last_target = lastsnapshot.search(lastsnapshot.root, main_target)!=null?lastsnapshot.search(lastsnapshot.root, main_target).target:null;
			file_target curr_target = currsnapshot.search(currsnapshot.root, main_target)!=null?currsnapshot.search(currsnapshot.root, main_target).target:null;
			if((curr_target!=null&&last_target!=null&&curr_target.modified_t!=last_target.modified_t)||
				(curr_target!=null&&last_target==null)||(curr_target==null&&last_target!=null)){
				work();
				if(curr_target!=null)	main_target = curr_target;
			}
			
			if(last_target!=null&&curr_target!=null&&curr_target.modified_t==last_target.modified_t&&
					main_target.type.equals("Directory")){
				//����modified��Ҫ��¼����
				file_node last_node = lastsnapshot.search(lastsnapshot.root, main_target);
				file_node curr_node = currsnapshot.search(currsnapshot.root, main_target);
				modified_compare(last_node, curr_node);//������Ҳ����
			}
		}
		else if(trigger.equals("path-changed")){
			if(main_target.type.equals("File")){
				file_target last_target = lastsnapshot.search(lastsnapshot.root, main_target)!=null?lastsnapshot.search(lastsnapshot.root, main_target).target:null;
				file_target curr_target = currsnapshot.search(currsnapshot.root, main_target)!=null?currsnapshot.search(currsnapshot.root, main_target).target:null;
				
				if(curr_target==null&&last_target!=null){
					file_node path_change_node = currsnapshot.path_change_search(currsnapshot.root, main_target);
					if(path_change_node!=null){
						work();
						main_target = path_change_node.target;
					}else{
						main_target = new file_target("", "", "", "", -1, -1);//ĿǰĬ�ϲ�����ɾ������������
					}
				}
			}else if(main_target.type.equals("Directory")){
				path_change_compare(main_target);
			}
		}
		else if(trigger.equals("size-changed")){
			file_target last_target = lastsnapshot.search(lastsnapshot.root, main_target)!=null?lastsnapshot.search(lastsnapshot.root, main_target).target:null;
			file_target curr_target = currsnapshot.search(currsnapshot.root, main_target)!=null?currsnapshot.search(currsnapshot.root, main_target).target:null;
			
			if((curr_target!=null&&last_target!=null&&curr_target.size!=last_target.size)||
					(curr_target!=null&&last_target==null)||(curr_target==null&&last_target!=null)){
				work();
				if(curr_target!=null)	main_target = curr_target;
			}
		}
		
	}
	
	public void work() {
		System.out.println("work");
	}
	
	public void update() {
		lastsnapshot.root = currsnapshot.root;
		currsnapshot.root = null;
	}

	public void modified_compare(file_node last_node,file_node curr_node){
		if(last_node.target.equals(curr_node.target)){
			last_node.target.compare = 1;
			curr_node.target.compare = 1;
			if(last_node.target.modified_t!=curr_node.target.modified_t){
				work();
			}
		}
		for(int i=0;i<last_node.child_nodelist.size();i++){
			for(int j=0;j<curr_node.child_nodelist.size();j++){
				modified_compare(last_node.child_nodelist.get(i), curr_node.child_nodelist.get(j));
			}
		}
		for(int i=0;i<last_node.child_nodelist.size();i++){
			if(last_node.child_nodelist.get(i).target.compare!=1){
				work();
			}
		}
		for(int i=0;i<curr_node.child_nodelist.size();i++){
			if(curr_node.child_nodelist.get(i).target.compare!=1){
				work();
			}
		}
	}
	
	public void path_change_compare(file_target target){
		if(target.type.equals("File")){
			file_target last_target = lastsnapshot.search(lastsnapshot.root, target)!=null?lastsnapshot.search(lastsnapshot.root, target).target:null;
			file_target curr_target = currsnapshot.search(currsnapshot.root, target)!=null?currsnapshot.search(currsnapshot.root, target).target:null;
			
			if(curr_target==null&&last_target!=null){
				file_node path_change_node = currsnapshot.path_change_search(currsnapshot.root, target);
				if(path_change_node!=null){
					work();
				}
			}
		}else if(target.type.equals("Directory")){
			file_node target_node = currsnapshot.search(currsnapshot.root, target);
			for(int i=0;i<target_node.child_nodelist.size();i++){
				path_change_compare(target_node.child_nodelist.get(i).target);
			}
		}	
	}
	
	public void renamed_compare(file_target target){
		if(target.type.equals("File")){
			file_target last_target = lastsnapshot.search(lastsnapshot.root, target)!=null?lastsnapshot.search(lastsnapshot.root, target).target:null;
			file_target curr_target = currsnapshot.search(currsnapshot.root, target)!=null?currsnapshot.search(currsnapshot.root, target).target:null;
			
			if(curr_target==null&&last_target!=null){
				file_node path_change_node = currsnapshot.renamed_search(currsnapshot.root, target);
				if(path_change_node!=null){
					work();
				}
			}
		}else if(target.type.equals("Directory")){
			file_node target_node = currsnapshot.search(currsnapshot.root, target);
			for(int i=0;i<target_node.child_nodelist.size();i++){
				renamed_compare(target_node.child_nodelist.get(i).target);
			}
		}
		
	}
	
	
}
