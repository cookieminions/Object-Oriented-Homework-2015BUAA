package IFTTT;

import java.util.Random;

public class filedemo extends Thread{
	private safe_file file;
	
	public filedemo(safe_file f) {
		file = f;
	}
	
	public void run(){
		System.out.println(System.currentTimeMillis()+"    "+getName()+" "+file.getName());
		System.out.println(System.currentTimeMillis()+"    "+getName()+" "+file.getParent());
		System.out.println(System.currentTimeMillis()+"    "+getName()+" "+file.getPath());
		try {
			//if(getName().equals("t1"))
			sleep(new Random().nextInt(5000));
				//sleep(5000);
			if(getName().equals("t1"))
				sleep(20000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(file.exist())	System.out.println("exits");
		else				System.out.println("its gone");
		System.out.println(System.currentTimeMillis()+"    "+getName()+" "+file.getlength());
		System.out.println(System.currentTimeMillis()+"    "+getName()+" "+file.lastModified());
		String[] str = file.filelist();
		System.out.println("---------------------"+getName()+"--------------------");
		for(int i=0;i<str.length;i++){
			System.out.println(System.currentTimeMillis()+"    "+str[i]);
		}
	}
	
	
	public static void main(String[] args) {
		FileList fileList = new FileList();
		
		safe_file file = fileList.get_shell("f:\\movie\\test");
		
		filedemo t1 = new filedemo(file);
		filedemo t2 = new filedemo(file);
		t1.setName("t1");
		t2.setName("t2");
		t1.start();
		t2.start();
	}
}
