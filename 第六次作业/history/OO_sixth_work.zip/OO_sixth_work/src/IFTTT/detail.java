package IFTTT;

public class detail {

}
