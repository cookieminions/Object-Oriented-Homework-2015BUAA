package IFTTT;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FileList {
	private Map<String, safe_file> filelist;
	
	FileList() {
		filelist = new HashMap<String,safe_file>();
	}
	
	public synchronized safe_file get_shell(String path) {
		safe_file file = getFile(path);
		if(file==null){
			file = new safe_file(path);
			addFile(path, file);
		}else{
			if(!file.exist()){
				remove(path);
				file = new safe_file(path);
				addFile(path, file);
			}
		}
		return file;
	}
	
	public synchronized safe_file getFile(String path){
		return filelist.get(path);
	}
	
	public synchronized void addFile(String path,safe_file file){
		filelist.put(path, file);
	}
	
	public synchronized void remove(String path){
		filelist.remove(path);
	}
	
	public synchronized void refresh() {
		Iterator<Map.Entry<String, safe_file>> it = filelist.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry<String, safe_file> entry=it.next();
			String key = entry.getKey();
			safe_file value = entry.getValue();
			if(!value.exist())	{
		    	it.remove();
		    }
		}
	}
}
