package IFTTT;


public class file_shell {
	private safe_file file = null;
	private FileList filelist;
	
	public file_shell(String path,FileList file_list) {
		filelist = file_list;
		
		file = filelist.getFile(path);
		if(file==null){
			file = new safe_file(path);
			filelist.addFile(path, file);
		}else{
			if(!file.exist()){
				filelist.remove(path);
				file = new safe_file(path);
				filelist.addFile(path, file);
			}
		}
	}
	
	

}
