package IFTTT;

public class Task {
	String task_str;
	private String path;
	private String trigger;
	private String task;
	
	Task(String str){
		String[] tasks = str.split(" ");
		task_str = str;
		path = tasks[1];
		trigger = tasks[2];
		task = tasks[4];
	}
	
	public void change_path(String str) {
		path = str;
	}
	public String get_path() {
		return path;
	}
	public String get_trigger() {
		return trigger;
	}
	public String get_task() {
		return task;
	}
	public boolean equals(Task tmp_task) {
		if(tmp_task.get_path().equals(path)&&tmp_task.get_trigger().equals(trigger)&&tmp_task.get_task().equals(task))
			return true;
		else	return false;
	}
	public String toString() {
		return task_str;
	}
}
