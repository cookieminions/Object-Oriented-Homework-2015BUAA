package IFTTT;

import java.io.File;

public class safe_file {
	private File file;
	
	safe_file(String path){
		file = new File(path);
	}
	
	public synchronized boolean isDirectory() {
		return file.isDirectory();
	}
	public synchronized boolean isFile() {
		return file.isFile();
	}
	
	public synchronized String getName(){
		return file.getName();
	}
	public synchronized String getPath(){
		return file.getPath();
	}
	public synchronized String getParent(){
		return file.getParent();
	}
	public synchronized long lastModified(){
		return file.lastModified();
	}
	public synchronized long getlength(){
		if(file.isFile())
			return file.length();
		else return 0;
	}
	public synchronized boolean exist(){
		return file.exists();
	}
	public synchronized String[] filelist() {
		String[] strlist = file.list();
		System.out.println(file.isFile());
		if(strlist!=null){
			for(int i=0;i<strlist.length;i++){
				strlist[i] = getPath()+"\\"+strlist[i];
				System.out.println(strlist[i]);
			}
		}
		return strlist;
	}
}
