package exp2;

public class FinancialOfficer extends Employee{
	
	FinancialOfficer(int id){
		super(id);
	}
	public void examine_account(String account){
		
	}
	
	public boolean get_order_money(double money){
		return true;
	}
}
