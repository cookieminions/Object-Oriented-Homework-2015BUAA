package exp2;

public interface PrintInfo {
	public String printBasicInfo();
	public String printDetailInfo();
}
