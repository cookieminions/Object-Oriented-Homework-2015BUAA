package Bank;

public class InvalidAccountException extends Exception {

}
