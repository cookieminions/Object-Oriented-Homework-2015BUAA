package Bank;

public class InvalidUserException extends Exception {

}
